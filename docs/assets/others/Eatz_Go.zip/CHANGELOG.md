# Changelog of EatzGo

- v0.0.1 Alpha A-1{master} (precedent snapshot)
- v0.0.1 Alpha B-2{master} (actual snapshot) {

    :new: Alpha B-2 is here with a lot of new features ! :muscle::rocket:

    - Fixed some bugs :bug:
    - Improved  performances :rocket: :muscle: 
    - Added lang support for French !! :abc: (other langs comming soon...)
    - Updated Online Documentations :books: !
    - Updated GithubDocs :octocat: !

    Thank you for supporting EatzGo Project :punch:, more things you will like soon ! :sunglasses:

}