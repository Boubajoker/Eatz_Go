# Changelog of EatzGo

- v0.0.1 Alpha A-1{master} (old snapshot)
- v0.0.1 Alpha B-2{master} (precedent snapshot)
- v0.0.1 Alpha C-3{master} (actual snapshot) {
    :new: Alpha C-3 is here with a lot of new features ! :muscle::rocket:

    - Fixed a lot bugs :bug:
    - Improved  performances :rocket: :muscle: 
    - Now theme manager is fixed :boom: !
    - Updated Online Documentations :books: !
    - Updated Github Documentations :octocat: :books: !
    - :new: Added [`EatzGoShell`](shell.py) :+1: !
    - Updated security protocol :alien: !
    - Removed `EatzGoConsole`
    - Added Vscode [`settings.json`](.vscode/settings.json) support !

    Thank you for supporting EatzGo Project :punch:, more things you will like soon ! :sunglasses:
    
    Delta A-1 coming soon... :eyes:
}