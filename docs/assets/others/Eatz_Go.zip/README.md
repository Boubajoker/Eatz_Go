# Eatz_Go :hamburger:
An IA that can prupose you what you can eat !!

# How to use it ?

Just execute '[main.py](main.py)' for devs.
And execute '[EatzGo](EatzGo.exe)' for normal using.

And that's it, the IA will prupose to you a meal !

# Requied to launch the project (dev)

- Git
- [Python 3.8.10 minimal version](https://python.org/)
- [Win7 64bits minimal](https://microsoft.com/)

# EatzGoConsole

EatzGoConsole is a simple buildit-in app that don't hide the console. 

# Online Documentation

for more info check [Eatz_Go documantation](https://boubajoker.github.io/Eatz_Go/")

# Conditions for share this project

DO NOT DO A COPY OF THIS PROJECT WITHOUT THE FOLLOWING FILES:
- [CopyRight.txt](CopyRight.txt)
- [ThirdPartyNotice.txt](ThirdPartyNotice.txt)
- [AUTHORS.md](AUTHORS.md)
- [LICENSE](LICENSE)

