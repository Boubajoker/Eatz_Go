function redirect_to_home() {
    window.location = "./home.html";
};
setTimeout(redirect_to_home, 8000);