//@ts-nocheck
declare function redirect_to_home(): Window;