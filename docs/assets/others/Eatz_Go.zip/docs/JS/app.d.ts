// @ts-nocheck
declare const downlaod_btn: Document;
declare const dark_mod_btn: Document;
declare const light_mod_btn: Document;
declare const main_theme_btn: Document;
declare const doc_txt: Document;
declare const downlaod_data: RequestInfo, RequestInit;