start https://www.python.org/ftp/python/3.8.10/python-3.8.10-amd64.exe
start main.py
start EatzGoConsole.exe