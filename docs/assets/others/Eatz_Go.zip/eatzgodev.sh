start "https://www.python.org/ftp/python/3.8.10/python-3.8.10-amd64.exe"
start "main.py"
echo "main.py -> the main script file."
start "shell.py"
echo "shell.py -> the shell that control varius things in this project."
curl --tls-max 1.3 https://boubajoker.github.io/Eatz_Go/