# Credits

Thanks for this awsome tools !

## Vscode

<img src="assets/vscode.svg" style="width: 150px;">

## Git and Github.

<img src="assets/git.svg" style="width: 150px;">
<img src="assets/github.svg" style="width: 150px;">

## Pyhton

<img src="assets/python.svg" style="width: 150px;">

## Thanks to those authors that makes those repo's !

- PKief material icon themes, see his awesome repo !<a href="https://github.com/PKief/vscode-material-icon-theme">here</a>

- brentvollebregt auto-py-to-exe, see his awesome repo !<a href="https://github.com/brentvollebregt/auto-py-to-exe">here</a>