# Eatz_Go
An IA that can prupose you what you can eat !!

# How to use it ?

Just execute <a href="main.py">'main.py'</a> for devs.
And execute <a href="EatzGo.exe">EatzGo.exe</a> for normal using.

And that's it, the IA will prupose to you a meal !

# Check out my other projects !

- <a href="https://github.com/Boubajoker/pypacket/">Pypacket</a>

# Conditions for share this project

DO NOT DO A COPY OF THIS PROJECT WITHOUT THE FOLLOWING FILES:
- CopyRight.txt
- ThirdPartyNotice.txt
- AUTHORS.md
- LICENSE
