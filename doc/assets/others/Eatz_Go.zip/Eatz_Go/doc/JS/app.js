const downlaod_btn = document.querySelector('#downlaod_btn');

downlaod_btn.addEventListener('click', () => {
    window.open("#")
})